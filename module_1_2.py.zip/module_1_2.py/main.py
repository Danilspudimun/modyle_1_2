Number_of_completed_remote_sensing = 12
Number_of_hours_spent = 1.5
course_name = 'Phyton'
Time_per_task =(Number_of_hours_spent / Number_of_completed_remote_sensing)
print('Курс:',course_name,'всего задач:',Number_of_completed_remote_sensing,'затрачено часов:',Number_of_hours_spent,'среднее время выполнения',Time_per_task,'часа.')
